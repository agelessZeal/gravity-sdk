import { NativeCurrency } from "./NativeCurrency";
import { Token } from "./Token";

export type Currency = NativeCurrency | Token;
