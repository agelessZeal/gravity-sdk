import JSBI from "jsbi";

// exports for external consumption
// export type BigintIsh = JSBI | bigint | string
export type BigintIsh = JSBI | number | string;
