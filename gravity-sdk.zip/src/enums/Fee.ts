// Fee
export enum Fee {
  MINIMUM = 5,
  DEFAULT = 25,
  MAXIMUM = 50
}
