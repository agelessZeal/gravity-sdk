module.exports = {
  ...require("@sushiswap/prettier-config")
};
